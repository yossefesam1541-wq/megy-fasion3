---
name: OpenAPI integer compatibility
description: Compatibility constraint between Orval output and the workspace Zod runtime.
---

When adding numeric fields to the OpenAPI contract, verify the generated validator against the workspace’s installed Zod version. In this workspace, OpenAPI `integer` fields were generated as `zod.int()`, but the installed Zod v3 runtime does not expose `z.int()`.

**Why:** Codegen itself succeeds, but the chained library typecheck fails after generation, which can block the frontend from receiving usable hooks.

**How to apply:** Prefer `type: number` when integer-specific validation is not essential, or explicitly align the Zod/codegen versions before relying on generated integer validators.